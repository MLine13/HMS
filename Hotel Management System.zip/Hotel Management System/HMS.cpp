//Mahdi Esmaili Jadidi

#include <iostream>
#include <string>
#define MAX_ROOMS 100

using namespace std;

// Customer class
class Customer {
public:
    string name;
    string address;
    string phone;
    string from_date;
    string to_date;
    float payment_advance;
    int booking_id;
};

// Room class
class Room {
public:
    char type; // AC or Non-AC
    char stype; // Size: Big or Small
    char ac; // Yes or No
    int roomNumber;
    int rent;
    int status; // 0 for available, 1 for booked
    Customer cust;

    Room addRoom(int);
    void searchRoom(int);
    void deleteRoom(int);
    void displayRoom(Room);
};

// Global array of rooms
Room rooms[MAX_ROOMS];
int count = 0;

// Function to add a room
Room Room::addRoom(int rno) {
    Room room;
    room.roomNumber = rno;
    cout << "\\nType AC/Non-AC (A/N): ";
    cin >> room.ac;
    cout << "\\nType Comfort (S/N): ";
    cin >> room.type;
    cout << "\\nType Size (B/S): ";
    cin >> room.stype;
    cout << "\\nDaily Rent: ";
    cin >> room.rent;
    room.status = 0;
    cout << "\\nRoom Added Successfully!";
    return room;
}

// Function to search for a room
void Room::searchRoom(int rno) {
    for (int i = 0; i < count; i++) {
        if (rooms[i].roomNumber == rno) {
            cout << "Room Details\\n";
            if (rooms[i].status == 1) {
                cout << "\\nRoom is Reserved";
            } else {
                cout << "\\nRoom is available";
            }
            displayRoom(rooms[i]);
            return;
        }
    }
    cout << "\\nRoom not found";
}

// Function to display room details
void Room::displayRoom(Room tempRoom) {
    cout << "\\nRoom Number: " << tempRoom.roomNumber;
    cout << "\\nType AC/Non-AC (A/N): " << tempRoom.ac;
    cout << "\\nType Comfort (S/N): " << tempRoom.type;
    cout << "\\nType Size (B/S): " << tempRoom.stype;
    cout << "\\nRent: " << tempRoom.rent;
}

// Main function
int main() {
    // Your code to interact with the user and manage the hotel system
    return 0;
}

// 5 / 25 / 2024