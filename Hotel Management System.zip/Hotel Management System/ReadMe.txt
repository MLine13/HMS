The hotel management system

This program has been written by Mahdi Esmaili Jadidi. It is used for managing hotel guests and their rooms. The program suggests suitable rooms to guests based on their details. It is written in the C++ programming language.